#!/bin/bash

java -cp target/classes:target/eo-runtime.jar org.eolang.phi.Main c2eo.app $1
